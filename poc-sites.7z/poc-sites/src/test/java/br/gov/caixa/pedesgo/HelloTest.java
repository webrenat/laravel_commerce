package br.gov.caixa.pedesgo;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class HelloTest {

    @Test
    public void getResponse() {
        assertEquals(new Integer(42), new Hello().getResponse());
    }
}