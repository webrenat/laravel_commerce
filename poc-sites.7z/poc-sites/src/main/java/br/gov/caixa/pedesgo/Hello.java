package br.gov.caixa.pedesgo;

public class Hello {

    public Integer getResponse() {
        return 42;
    }
}