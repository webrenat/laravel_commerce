## Como rodar
```mvn clean test site:run```